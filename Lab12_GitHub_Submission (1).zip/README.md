# Lab 12 – Monitoring Windows 11

This folder contains the prepared answer worksheet for Lab 12.

## Files
- `Lab12_Monitoring_Windows_Answers.docx` — answer worksheet with screenshot placeholders.

## Important
Some answers depend on the actual Windows 11 computer (event counts, running apps, memory usage, CPU cores, active processes, network connection details, and indexed folders). These are marked `[FILL IN FROM YOUR PC]`; they must be completed using your own computer.

The worksheet also contains 9 screenshot placeholders. Insert real screenshots from your Windows 11 PC before submitting. Do not submit the placeholders as if they were screenshots.

## Upload to GitHub
1. Open the repository provided by your teacher.
2. Choose **Add file → Upload files**.
3. Upload the completed `.docx` file (and this README if requested).
4. Click **Commit changes**.
